SNOW RIDER WINDOWS EXE BUILD

This project keeps the Android APK workflow and adds a self-contained Windows EXE workflow.

TO BUILD THE WINDOWS EXE ON GITHUB
1. Upload the contents of this SnowRiderApp folder to the root of your GitHub repository.
2. Keep the original Android game page at app/src/main/assets/index.html, or keep the original SnowRider ZIP in the repository.
3. The build-exe.yml workflow creates desktop-app/package.json, desktop-app/main.js and desktop-app/index.html automatically. You do NOT need to upload a desktop-app folder yourself.
4. Open the repository Actions tab, select “Build Snow Rider Windows EXE”, then click “Run workflow”.
5. Download the “SnowRider-Windows-EXE” artifact from the completed run.

The artifact should contain a Windows installer and a portable EXE.

IMPORTANT GAME NOTE
The supplied index.html loads the Unity game files from jsDelivr. The desktop EXE therefore needs an internet connection. This wrapper does not turn the remote Unity game into an offline game.
