SNOW RIDER 3D ANDROID PROJECT — READ THIS FIRST

WHAT THIS ZIP IS
This is an Android Studio project (source code), NOT an APK installer.
It wraps a web-hosted Unity game in an Android WebView. The game files are
loaded from jsDelivr over the internet, so the app needs an internet connection.
The actual Unity game files are not bundled inside this ZIP.

WHAT I FOUND / FIXED
- The Android app source, manifest, Gradle build files, and game page are present.
- The Gradle wrapper is INCOMPLETE: gradle-wrapper.properties exists, but the
  gradlew launcher, gradlew.bat, and gradle-wrapper.jar are missing.
- This ZIP includes this setup guide so you can complete the wrapper before
  building. I could not produce an APK in this environment because it does not
  have the Android SDK/build tools installed.

HOW TO MAKE THE APK (WINDOWS)
1. Install Android Studio from the official Android developer website.
2. Open Android Studio, then choose Open and select the extracted
   SnowRiderApp folder (the folder containing settings.gradle).
3. If Android Studio reports that the Gradle wrapper is missing, install
   Gradle 8.2 on your computer and add its bin folder to PATH.
   (Use Gradle 8.2, matching the project's gradle-wrapper.properties.)
4. Open the Android Studio Terminal at the project root — the folder containing
   settings.gradle — and run:
       gradle wrapper --gradle-version 8.2
   This generates gradlew, gradlew.bat, and gradle/wrapper/gradle-wrapper.jar.
5. In Android Studio, set the Gradle JDK to JDK 17:
   File > Settings > Build, Execution, Deployment > Build Tools > Gradle.
6. Let Gradle sync. If prompted to install Android SDK Platform 34 or Android
   Build Tools, accept the Android Studio SDK Manager installation.
7. Build the APK:
   Build > Build Bundle(s) / APK(s) > Build APK(s)
8. When the build finishes, click "locate". The debug APK should be at:
       app/build/outputs/apk/debug/app-debug.apk

HOW TO PUT IT ON YOUR ANDROID PHONE
1. Transfer app-debug.apk to your phone.
2. Tap the APK in your phone's Files app and follow Android's install prompt.
   Only install APKs you built yourself or trust.
3. Open "Snow Rider 3D". Keep internet connected because the game content is
   loaded online.

IMPORTANT
- This is a debug APK for personal testing, not a Play Store release.
- If the game screen is blank, check internet access first. The game depends on
  external files hosted at jsDelivr; those files are not inside this ZIP.
- This project uses package ID com.snowrider.devtools and app label Snow Rider 3D.

BUILDING DIRECTLY FROM AN ANDROID TABLET (NO ANDROID STUDIO NEEDED)
A GitHub Actions workflow is included at .github/workflows/build-apk.yml.
1. In your tablet browser, sign in to GitHub (github.com) or create an account.
2. Create a new repository. You can keep it Private. Name it SnowRiderApp.
3. Choose Add file > Upload files, then upload the CONTENTS of the extracted
   SnowRiderApp folder, including the hidden .github folder. If your file picker
   hides .github, use GitHub's web editor to create the workflow file at
   .github/workflows/build-apk.yml and paste in the included file's contents.
4. Commit the uploaded files.
5. Open the repository's Actions tab. Select "Build Snow Rider APK".
6. Tap Run workflow and confirm Run workflow.
7. Wait for the run to finish successfully. Open that run and download the
   "SnowRider-debug-APK" artifact. GitHub may download it as a ZIP.
8. Open the downloaded artifact ZIP in Files and extract app-debug.apk.
9. Tap app-debug.apk to install it. Android may ask you to allow your browser
   or Files app to install apps; only allow this for the APK you built yourself.

NOTE: GitHub account/repository setup and Actions availability may vary. The
APK is a debug build for personal testing. The game content is loaded online.
